"""
REINFORCE policy agent for OBELIX (evaluation-only).

Loads trained policy weights from weights.pth.

Submission ZIP:
    submission.zip
        agent.py
        weights.pth
"""

from __future__ import annotations
from typing import List, Optional
import os
import numpy as np
import torch
import torch.nn as nn


ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]


class PolicyNet(nn.Module):
    def __init__(self, in_dim: int = 18, n_actions: int = 5):
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, n_actions),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


_model: Optional[PolicyNet] = None
_last_action: Optional[int] = None
_repeat_count: int = 0

# 🔥 blinking memory
_prev_obs: Optional[np.ndarray] = None

# unwedge state
_unwedge_steps: int = 0
_unwedge_dir: Optional[str] = None

_MAX_REPEAT = 2
_CLOSE_PROB_DELTA = 0.05


def _load_once():
    global _model

    if _model is not None:
        return

    here = os.path.dirname(__file__)
    wpath = os.path.join(here, "weights_new.pth")

    if not os.path.exists(wpath):
        raise FileNotFoundError(
            "weights.pth not found next to agent.py."
        )

    m = PolicyNet()
    sd = torch.load(wpath, map_location="cpu")

    if isinstance(sd, dict) and "state_dict" in sd:
        sd = sd["state_dict"]

    m.load_state_dict(sd, strict=True)
    m.eval()

    _model = m


@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _last_action, _repeat_count
    global _unwedge_steps, _unwedge_dir
    global _prev_obs

    _load_once()

    # ------------------------------------------------
    # 🔥 BLINKING DETECTION (BOX vs WALL)
    # ------------------------------------------------
    if _prev_obs is None:
        _prev_obs = obs.copy()

    delta = np.abs(obs - _prev_obs)

    # threshold → blinking = box
    blink_mask = (delta > 0.2).astype(np.float32)

    static_mask = obs * (1 - blink_mask)   # walls
    dynamic_mask = obs * blink_mask        # box

    _prev_obs = obs.copy()

    # ------------------------------------------------
    # 🔍 SENSOR SPLIT
    # ------------------------------------------------
    left_w  = np.sum(static_mask[0:4])
    front_w = np.sum(static_mask[7:9])
    right_w = np.sum(static_mask[12:16])

    left_b  = np.sum(dynamic_mask[0:4])
    front_b = np.sum(dynamic_mask[7:9])
    right_b = np.sum(dynamic_mask[12:16])

    stuck = obs[17]

    # ------------------------------------------------
    # 🎯 PRIORITY: GO TO BOX
    # ------------------------------------------------
    if front_b > 0 and front_w == 0:
        return "FW"

    if left_b > right_b and left_b > 0:
        return "L22"

    if right_b > left_b and right_b > 0:
        return "R22"

    # ------------------------------------------------
    # 🚨 BOX NEAR WALL (MAIN BUG FIX)
    # ------------------------------------------------
    if front_b > 0 and front_w > 0:
        if left_w > right_w:
            return "R45"
        else:
            return "L45"

    # ------------------------------------------------
    # 🧱 WALL AVOIDANCE
    # ------------------------------------------------
    if front_w > 2:
        if left_w > right_w:
            return "R45"
        else:
            return "L45"

    # ------------------------------------------------
    # 🔄 PRE-UNWEDGE (CORNER DETECTION)
    # ------------------------------------------------
    if front_w > 1 and (left_w > 1 or right_w > 1):
        if left_w > right_w:
            _unwedge_dir = "R45"
        else:
            _unwedge_dir = "L45"

        _unwedge_steps = 5
        return _unwedge_dir

    # ------------------------------------------------
    # 🔥 STRONG UNWEDGE (STUCK)
    # ------------------------------------------------
    if stuck == 1 and _unwedge_steps == 0:
        if left_w > right_w:
            _unwedge_dir = "R45"
        elif right_w > left_w:
            _unwedge_dir = "L45"
        else:
            _unwedge_dir = "L45" if rng.random() < 0.5 else "R45"

        _unwedge_steps = 64

    if _unwedge_steps > 0:
        _unwedge_steps -= 1

        if _unwedge_steps % 2 == 0:
            return _unwedge_dir
        else:
            return "FW"

    # ------------------------------------------------
    #  WALL FOLLOW BREAK
    # ------------------------------------------------
    if left_w > 0 and front_w == 0 and right_w == 0:
        return "R22"

    if right_w > 0 and front_w == 0 and left_w == 0:
        return "L22"

    # ------------------------------------------------
    # FALLBACK: NEURAL POLICY
    # ------------------------------------------------
    x = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
    logits = _model(x)

    probs = torch.softmax(logits, dim=1).squeeze(0).cpu().numpy()
    best = int(np.argmax(probs))

    # ------------------------------------------------
    #  SMOOTHING
    # ------------------------------------------------
    if _last_action is not None:
        order = np.argsort(-probs)
        best_p = probs[order[0]]
        second_p = probs[order[1]]

        if (best_p - second_p) < _CLOSE_PROB_DELTA:
            if _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0

    _last_action = best
    return ACTIONS[best]