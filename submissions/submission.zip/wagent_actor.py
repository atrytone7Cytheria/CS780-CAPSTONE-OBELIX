"""
Actor-Critic evaluation agent for OBELIX (CPU).

Loads pretrained weights from weights.pth and runs a deterministic policy.

Submission zip:
    submission.zip
        agent.py
        weights.pth
"""

from __future__ import annotations
from typing import List, Optional
import os
import numpy as np
import torch
import torch.nn as nn

ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]


# -------------------------
# Network (same as trainer)
# -------------------------

class ActorCritic(nn.Module):
    def __init__(self, in_dim: int = 18, n_actions: int = 5):
        super().__init__()

        self.shared = nn.Sequential(
            nn.Linear(in_dim,128),
            nn.ReLU(),
            nn.Linear(128,128),
            nn.ReLU()
        )

        self.actor = nn.Linear(128,n_actions)
        self.critic = nn.Linear(128,1)

    def forward(self,x):

        h = self.shared(x)

        logits = self.actor(h)
        value = self.critic(h)

        return logits,value


_model: Optional[ActorCritic] = None
_last_action: Optional[int] = None
_repeat_count: int = 0

_MAX_REPEAT = 2
_CLOSE_DELTA = 0.05


# -------------------------
# Load weights once
# -------------------------

def _load_once():

    global _model

    if _model is not None:
        return

    here = os.path.dirname(__file__)
    wpath = os.path.join(here,"weights.pth")

    if not os.path.exists(wpath):
        raise FileNotFoundError(
            "weights.pth not found next to agent.py"
        )

    m = ActorCritic()

    sd = torch.load(wpath,map_location="cpu")

    if isinstance(sd,dict) and "state_dict" in sd:
        sd = sd["state_dict"]

    m.load_state_dict(sd,strict=True)
    m.eval()

    _model = m


# -------------------------
# Policy function
# -------------------------

@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:

    global _last_action,_repeat_count

    _load_once()

    x = torch.tensor(obs,dtype=torch.float32).unsqueeze(0)

    logits,_ = _model(x)

    temperature = 0.7
    probs = torch.softmax(logits/temperature, dim=1).squeeze(0).cpu().numpy()
    best = rng.choice(len(ACTIONS), p=probs)


    # action smoothing to avoid jitter
    if _last_action is not None:

        order = np.argsort(-probs)

        best_p = float(probs[order[0]])
        second_p = float(probs[order[1]])

        if (best_p-second_p) < _CLOSE_DELTA:

            if _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0


    _last_action = best

    return ACTIONS[best]