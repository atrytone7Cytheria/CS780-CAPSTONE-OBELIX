from __future__ import annotations
from typing import List, Optional
import os
import numpy as np
import torch
import torch.nn as nn


ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]


# -----------------------------
# SAME ARCH AS TRAINING
# -----------------------------
class ActorCritic(nn.Module):
    def __init__(self, in_dim=18, n_actions=5):
        super().__init__()

        self.shared = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
        )

        self.actor = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, n_actions)
        )

    def forward(self, x):
        x = self.shared(x)
        return self.actor(x)


_model: Optional[ActorCritic] = None
_last_action: Optional[int] = None
_repeat_count: int = 0

_unwedge_steps: int = 0
_unwedge_dir: Optional[str] = None

_MAX_REPEAT = 2
_CLOSE_PROB_DELTA = 0.03


def _load_once():
    global _model

    if _model is not None:
        return

    here = os.path.dirname(__file__)
    wpath = os.path.join(here, "weights_difficult.pth")

    m = ActorCritic()

    sd = torch.load(wpath, map_location="cpu")

    if isinstance(sd, dict) and "state_dict" in sd:
        sd = sd["state_dict"]

    m.load_state_dict(sd, strict=False)
    m.eval()

    _model = m


@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _last_action, _repeat_count
    global _unwedge_steps, _unwedge_dir

    _load_once()

    left  = np.sum(obs[0:4])
    front = np.sum(obs[4:12])
    right = np.sum(obs[12:16])
    stuck = obs[17]

    # -----------------------------
    # UNWEDGE
    # -----------------------------
    if stuck == 1 and _unwedge_steps == 0:
        _unwedge_steps = 4
        _unwedge_dir = "L45" if rng.random() < 0.5 else "R45"

    if _unwedge_steps > 0:
        _unwedge_steps -= 1
        if _unwedge_steps == 1:
            return "FW"
        return _unwedge_dir

    if sum(obs[1:17]) == 0:
        return "FW"

    # -----------------------------
    # SIDE WALL FIX
    # -----------------------------
    if (left > 0 and front == 0 and right == 0):
        return "R22"

    if (right > 0 and front == 0 and left == 0):
        return "L22"

    # -----------------------------
    # PPO POLICY (ACTOR ONLY)
    # -----------------------------
    x = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
    logits = _model(x)

    probs = torch.softmax(logits, dim=1).squeeze(0).cpu().numpy()
    best = int(np.argmax(probs))
    # ------------------------------------------------
    if _last_action is not None:

        order = np.argsort(-probs)
        best_p = probs[order[0]]
        second_p = probs[order[1]]

        if (best_p - second_p) < _CLOSE_PROB_DELTA:

            if _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0

    _last_action = best
    return ACTIONS[best]