"""
PPO / Actor-Critic evaluation agent for OBELIX (CPU).

Loads pretrained weights from weights.pth and runs a deterministic policy.

Submission ZIP:
    submission.zip
        agent.py
        weights.pth
"""

from __future__ import annotations
from typing import List, Optional
import os
import numpy as np
import torch
import torch.nn as nn

ACTIONS: List[str] = ["L45","L22","FW","R22","R45"]


# ------------------------------------------------
# Network (must match training architecture)
# ------------------------------------------------

class ActorCritic(nn.Module):

    def __init__(self,in_dim: int = 18,n_actions: int = 5):
        super().__init__()

        self.shared = nn.Sequential(
            nn.Linear(in_dim,64),
            nn.ReLU(),
            nn.Linear(64,64),
            nn.ReLU()
        )

        self.actor = nn.Linear(64,n_actions)
        self.critic = nn.Linear(64,1)

    def forward(self,x: torch.Tensor):

        h = self.shared(x)

        logits = self.actor(h)
        value = self.critic(h)

        return logits,value


# ------------------------------------------------
# Global model cache
# ------------------------------------------------

_model: Optional[ActorCritic] = None
_last_action: Optional[int] = None
_repeat_count: int = 0

_MAX_REPEAT = 2
_CLOSE_DELTA = 0.05


# ------------------------------------------------
# Load weights once
# ------------------------------------------------

def _load_once():

    global _model

    if _model is not None:
        return

    here = os.path.dirname(__file__)
    wpath = os.path.join(here,"weights.pth")

    if not os.path.exists(wpath):
        raise FileNotFoundError(
            "weights.pth not found next to agent.py"
        )

    m = ActorCritic()

    sd = torch.load(wpath,map_location="cpu")

    if isinstance(sd,dict) and "state_dict" in sd:
        sd = sd["state_dict"]

    m.load_state_dict(sd,strict=True)
    m.eval()

    _model = m


# ------------------------------------------------
# Policy
# ------------------------------------------------

@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:

    global _last_action,_repeat_count

    _load_once()

    x = torch.tensor(obs,dtype=torch.float32).unsqueeze(0)

    logits,_ = _model(x)

    logits = logits.squeeze(0).cpu().numpy()

    best = int(np.argmax(logits))


    # ------------------------------------------------
    # Action smoothing (avoid oscillation)
    # ------------------------------------------------

    if _last_action is not None:

        order = np.argsort(-logits)

        best_val = float(logits[order[0]])
        second_val = float(logits[order[1]])

        if (best_val-second_val) < _CLOSE_DELTA:

            if _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0


    _last_action = best

    return ACTIONS[best]