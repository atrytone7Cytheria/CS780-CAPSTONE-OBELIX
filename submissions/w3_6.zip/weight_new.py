"""
Actor-Critic policy agent for OBELIX (evaluation-only).

Loads trained AC weights from weights_ac.pth.
"""

from __future__ import annotations
from typing import List, Optional
import os
import numpy as np
import torch
import torch.nn as nn


ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]


# -----------------------------
# MATCH TRAINING ARCH (AC)
# -----------------------------
class ActorCritic(nn.Module):
    def __init__(self, in_dim: int = 18, n_actions: int = 5):
        super().__init__()

        self.shared = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
        )

        self.actor = nn.Linear(128, n_actions)
        self.critic = nn.Linear(128, 1)  # unused in eval

    def forward(self, x: torch.Tensor):
        x = self.shared(x)
        return self.actor(x), self.critic(x)


_model: Optional[ActorCritic] = None
_last_action: Optional[int] = None
_repeat_count: int = 0

_unwedge_steps: int = 0
_unwedge_dir: Optional[str] = None

_MAX_REPEAT = 2
_CLOSE_PROB_DELTA = 0.03


# -----------------------------
# LOAD MODEL
# -----------------------------
def _load_once():
    global _model

    if _model is not None:
        return

    here = os.path.dirname(__file__)
    wpath = os.path.join(here, "weights_ac.pth")

    if not os.path.exists(wpath):
        raise FileNotFoundError("weights_ac.pth not found next to agent.py")

    m = ActorCritic()

    sd = torch.load(wpath, map_location="cpu")
    if isinstance(sd, dict) and "state_dict" in sd:
        sd = sd["state_dict"]

    m.load_state_dict(sd, strict=False)
    m.eval()

    _model = m


# -----------------------------
# POLICY
# -----------------------------
@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _last_action, _repeat_count
    global _unwedge_steps, _unwedge_dir

    _load_once()

    left  = np.sum(obs[0:4])
    front = np.sum(obs[4:12])
    right = np.sum(obs[12:16])
    stuck = obs[17]

    # ------------------------------------------------
    # PRE-UNWEDGE (EARLY ESCAPE)
    # ------------------------------------------------
    if front > 2 and (left > 1 or right > 1):

        if left > right:
            _unwedge_dir = "R45"
        else:
            _unwedge_dir = "L45"

        _unwedge_steps = 5
        return _unwedge_dir

    # ------------------------------------------------
    # STRONG UNWEDGE
    # ------------------------------------------------
    if stuck == 1 and _unwedge_steps == 0:

        if left > right:
            _unwedge_dir = "R45"
        elif right > left:
            _unwedge_dir = "L45"
        else:
            _unwedge_dir = "L45" if rng.random() < 0.6 else "R45"

        _unwedge_steps = 4

    if _unwedge_steps > 0:
        _unwedge_steps -= 1

        if _unwedge_steps % 2 == 0:
            return _unwedge_dir
        else:
            return "FW"

    # ------------------------------------------------
    # SIDE WALL FIX
    # ------------------------------------------------
    if (left > 0 and front == 0 and right == 0):
        return "R22"

    if (right > 0 and front == 0 and left == 0):
        return "L22"

    # ------------------------------------------------
    # FORWARD BIAS (LIGHT)
    # ------------------------------------------------
    if front > 0 and stuck == 0:
        return "FW"

    # ------------------------------------------------
    # MODEL ACTION
    # ------------------------------------------------
    x = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)

    logits, _ = _model(x)   # only actor used

    probs = torch.softmax(logits, dim=1).squeeze(0).cpu().numpy()
    best = int(np.argmax(probs))

    # ------------------------------------------------
    # SMOOTHING
    # ------------------------------------------------
    if _last_action is not None:

        order = np.argsort(-probs)
        best_p = probs[order[0]]
        second_p = probs[order[1]]

        if (best_p - second_p) < _CLOSE_PROB_DELTA:

            if _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0

    _last_action = best
    return ACTIONS[best]